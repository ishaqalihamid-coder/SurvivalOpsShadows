SHADOW OPS: SURVIVAL — MOBILE APK PROJECT

This project wraps the live Shadow Ops: Survival game in an Android WebView.

BUILD ON AN ANDROID PHONE:
1. Extract this ZIP.
2. Open the extracted folder in an Android-compatible IDE such as Code On The Go or another Android Gradle IDE.
3. Allow Gradle/Android SDK downloads when asked.
4. Run Sync/Build.
5. Choose Build APK / Assemble Debug.
6. Install the generated APK on your phone.

IMPORTANT:
- Internet is required because the game is loaded from the live AppDeploy URL.
- The APK is a wrapper around the current live game; it does not contain an offline copy of the game.
- If the IDE asks for Android SDK 35, install it.
- If Gradle asks to download dependencies, allow it on Wi-Fi.

GAME URL:
https://shadow-ops-survival-yi1nba.v2.appdeploy.ai/
